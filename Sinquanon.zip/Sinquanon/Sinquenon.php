<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sinequenon</title>
    <meta content="" name="descriptison">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


</head>

<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
    <img style="width:80px" src="logo.jpg" alt="">
    </div>
    <h1  style="color:blue;" class="titre">GENERIC STALKER DATA COLLECTION SHEET</h1>
  </div>
</nav>
  


    <section>
        
        <div class="container-fluid ">



            <div class="row">
                <div class="col-3 col-md-3 col-lg-3">


                    <label for="textinput">Date:</label>

                    <input autofocus maxlength="5" size="40"  id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>

                <div class="col-3 col-md-3 col-lg-3">

                    <label for="textinput">Time:</label>

                    <input  autofocus maxlength="5" size="40" id="textinput" name="textinput" type="text" placeholder="placeholder">am/pm

                </div>
                <div class="col-3 col-md-3 col-lg-3">

                    <label for="textinput">Originator:</label>

                    <input autofocus maxlength="5" size="40"  id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>

                <div class="col-3 col-md-3 col-lg-3">

                  <label for="textinput">Originator:</label>

                  <input autofocus maxlength="5" size="40"  id="textinput" name="textinput" type="text" placeholder="placeholder">  

                </div>

            </div>
        </div>

        <div class="container-fluid formulaire">



            <div class="row">
                <div class="col-3 col-md-3 col-lg-3">


                    <label for="textinput">Femem</label>

                    <input type="radio" name="sex" />

                    <label class="male" style="margin-left:25px" for="textinput">Male</label>

                    <input type="radio" name="sex" />
                </div>

                <div class="col-3 col-md-3 col-lg-3">

                    <label for="textinput">Time:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">am/pm

                </div>
                <div class="col-3 col-md-3 col-lg-3">

                    <label for="textinput">Originator:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>

                <div class="col-3 col-md-3 col-lg-3">

                    <label for="textinput">Originator:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>

            </div>
        </div>


        <div class="container-fluid formulaire">



            <div class="row">
                <div class="col-4 col-md-4 col-lg-4">

                    <label for="textinput">Time:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">am/pm

                </div>
                <div class="col-4 col-md-4 col-lg-4">

                    <label for="textinput">Originator:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>

                <div class="col-4 col-md-4 col-lg-4">

                    <label for="textinput">Originator:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>

            </div>
        </div>

        <div class="container-fluid formulaire">
            <div class="row">
                <div class="col-4 col-md-4 col-lg-4">

                    <label for="textinput">Time:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">am/pm

                </div>
                <div class="col-4 col-md-4 col-lg-4">

                    <label for="textinput">Originator:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>

                <div class="col-4 col-md-4 col-lg-4">

                    <label for="textinput">Originator:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>

            </div>
        </div>

        <div class="container-fluid formulaire">
            <div class="row">
                <div class="col-6 col-md-6 col-lg-6">

                    <label for="textinput">Time:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">am/pm

                </div>
                <div class="col-6 col-md-6 col-lg-6">

                    <label for="textinput">Originator:</label>

                    <input id="textinput" name="textinput" type="text" placeholder="placeholder">

                </div>


            </div>
        </div>

        <div class="container">
            <div class="d-flex justify-content-start">
                <h1 class="titre">GENERIC STALKER DATA COLLECTION SHEET</h1>

            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-12 col-md-12 col-lg-12">


                    <textarea id="subject" rows="20" name="subject" placeholder="Write something.."
                        style="width:80%;height:200px"></textarea>
                </div>
            </div>
        </div>



    </section>

    <section>
        <div class="container formulaire">
            <div class="row">
                <div class="col-3 col-md-3 col-lg-3">
                    <center>
                        <h1 class="titre">VOICE</h1>
                    </center>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                </div>

                <div class="col-3 col-md-3 col-lg-3">
                    <p></p>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                </div>

                <div class="col-3 col-md-3 col-lg-3">
                    <h1 class="titre">VOICE</h1>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                </div>
                <div class="col-3 col-md-3 col-lg-3">
                    <h1 class="titre">VOICE</h1>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                        <label class="form-check-label" for="defaultCheck1">
                            Default checkbox
                        </label>

                    </div>
                </div>


            </div>
        </div>

    </section>

    <section>
        <div class="container-fluid">
            <div class="row">

                <div class="col-4 col-md-4 col-lg-4">
                    <label for="textinput">Was law enforcement notified? </label>


                </div>
                <div class="col-4 col-md-4 col-lg-4">
                    <label for="textinput">Yes</label>

                    <input type="radio" name="sex" />
                </div>
                <div class="col-4 col-md-4 col-lg-4">
                    <label for="textinput">No</label>

                    <input type="radio" name="sex" />
                </div>
            </div>
    </section>
    <section>
        <div class="container-fluid formulaire">
            <div class="row">
                <div class="col-4 col-md-4 col-lg-4">

                    <label for="textinput">If yes, who and when? NAME:</label>

                </div>
                <div class="col-4 col-md-4 col-lg-4">
                    <input type="text" name="sex" />
                </div>
                <div class="col-4 col-md-4 col-lg-4">
                    <input type="text" name="sex" />
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid formulaire">
            <div class="row">
                <div class="col-6 col-md-6 col-lg-6">

                    <label for="textinput">If yes, who and when? NAME:</label>

                </div>
                <div class="col-6 col-md-6 col-lg-6">
                    <input type="text" name="sex" />
                </div>

            </div>
        </div>
    </section>
    <section>
        <h1 class="titre">Stalker Threat Assessment
            INITIAL CONTACT PHASE</h1>
        <div class="contaier">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">

                    <p>This document can be used as a starting point in the initial phase of assessing a potential
                        threat. This
                        should NOT limit other sources of information that may be invaluable in assessing a threat.</p>
                </div>
            </div>
        </div>
    </section>
    <div class="container-fluid formulaire">
        <div class="row">
            <div class="col-3 col-md-3 col-lg-3">


                <label for="textinput">Date:</label>

                <input id="textinput" name="textinput" type="text" placeholder="placeholder">

            </div>

            <div class="col-3 col-md-3 col-lg-3">

                <label for="textinput">Time:</label>

                <input id="textinput" name="textinput" type="text" placeholder="placeholder">am/pm

            </div>

            <div class="col-3 col-md-3 col-lg-3">


                <label for="textinput">Date:</label>

                <input id="textinput" name="textinput" type="text" placeholder="placeholder">

            </div>

            <div class="col-3 col-md-3 col-lg-3">

                <label for="textinput">Time:</label>

                <input id="textinput" name="textinput" type="text" placeholder="placeholder">am/pm

            </div>
        </div>
    </div>
    <section>
        <div class="container-fluid formulaire">
            <div class="row">
                <div class="col-6 col-md-6 col-lg-6">

                    <label for="textinput">If yes, who and when? NAME:</label>

                </div>
                <div class="col-6 col-md-6 col-lg-6">
                    <input style="margin-left:-500px" type="text" name="User" class="form-control">
                </div>

            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid formulaire">
            <div class="row">
                <div class="col-6 col-md-6 col-lg-6">

                    <label for="textinput">If yes, who and when? NAME:</label>

                </div>
                <div class="col-6 col-md-6 col-lg-6">
                    <input style="margin-left:-500px" type="text" name="User" class="form-control">
                </div>

            </div>
        </div>
    </section>

    <section>
        <h1>Step One</h1>
        <div class="container">
            <div class="d-flex justify-content-center">
                <div class="col-12 col-md-12 col-lg-12">
                    <h1 class="threat">TYPES OF THREAT</br>
                        (is this a threat?)
                    </h1>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <h1> DIRECT THREAT</h1>
                    <p>

                        Identifies a specific act against a specific target and is delivered in a straightforward,
                        clear, and explicit
                        manner. “I’m going to place a bomb in your bos
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <h1>  INDIRECT THREAT</h1>
                    <p>

                  
Tends to be vague, unclear, or ambiguous. The plan, intended victim(s), motivation, and other aspects of
the threat are masked or equivocal. “If I wanted to, I could kill everyone in this office.” Violence is
implied but tentatively, “if I wanted to” and suggests a violent act COULD occur, not that it WILL occur. 

                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <h1> VEILED THREAT</h1>
                    <p>
                   
Strongly implies but does not explicitly threaten violence. “We would be better off without you around
anymore.” clearly hits at the possible violent act, but leaves it to the potential victim to interpret the
message and give a definite meaning.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <h1>  CONDITIONAL THREAT</h1>
                    <p>

                   
Warns that a violent act will happen unless certain demands or terms are met. “If you don’t pay me a
million dollars, I’m going to shoot up the store.
                        manner. “I’m going to place a bomb in your bos
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <h1>Step Two</h1>
        <div class="container">
            <div class="d-flex justify-content-center">
            <h1 class="threat">LEVELS OF THREAT</br></h1>
                <div class="col-12 col-md-12 col-lg-12">
                   
                   <h1> This step can be used alone if the person making threat is unknown.</h1>
                  
                </div>
            </div>
        </div>
    </section>
    <section>
        <h1>Step Two</h1>
        
    </section>

    <section>
   
        <div class="container-fluid">
            <div class="d-flex justify-content-center">
                <div class="col-4 col-md-4 col-lg-4">
                <h1>  LOW LEVEL </h1>
                    <p>

                   
                    Threat is vague and indirect.<br>Information within the threat
                    is inconsistent,<br> implausible or lacks detail. <br>
                    Threat lacks realism. <br>
                    Content suggests person is unlikely to carry it out.
                    </p>
                </div>
                <div class="col-4 col-md-4 col-lg-4">
                <h1>  MED LEVEL </h1>
                    <p>
                    Threat is more direct and more
                    Concrete than low level threat.
                    Wording suggest person has
                    given some thought to how the
                    act would be carried out.
                    General indication of a possible
                    place and time (but not a detailed plan)
                    Strong indication the person has taken preparatory steps,
                    although there may be some 
                    veiled reference or ambiguous or inconclusive evidence pointing to
                    that possibility, an allusion to a 
                    book or movie that shows the
                    planning of a violent act, or a
vague, general statement about
the availability of weapons.
Specific statement seeking to
convey that the threat is not empty.
“I’m serious!” or “I really mean this!"

  
                    </p>
                </div>
                <div class="col-4 col-md-4 col-lg-4">
                <h1>  HIGH LEVEL
</h1>
                    <p>
                    Direct, specific, and plausible.
                    Threat suggests concrete steps
                    have been taken toward carrying it out, for example,
                    statements indicating that the person has acquired or practiced with a weapon or
                    has had the victim under surveillance.
                    “At 8:00am tomorrow morning I will shoot James. That’s when he leaves his house. I have a 9mm.
                    Believe me, I know what I am doing. I am sick and tired of what he is doing.”

                   
       
                    </p>
                </div>
    </section>
    <section>
    
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                <button  type="button" class="btn btn-warning">Warning</button>
                </div>
            </div>
        </div>
     
    </section>
</body>

</html>